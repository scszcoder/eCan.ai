
import crypto from 'crypto';
// import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
// import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";


import { DynamoDBClient, PutItemCommand, QueryCommand, DeleteItemCommand, ScanCommand } from "@aws-sdk/client-dynamodb";

// Initialize DynamoDB client
const client = new DynamoDBClient({ region: "us-east-1" });
// const docClient = DynamoDBDocumentClient.from(client);
const UNRECOGNIZED_INPUT = {error: "Unrecognized API"};

async function saveApiKey(apiKeyItem) {
    const params = {
        TableName: "ECBApiKeys",
        Item: {
            "apikey": { "S": apiKeyItem.apikey },
            "user": { "S": apiKeyItem.customerId },
            "customer": { "S": apiKeyItem.customer },
            "status": { "S": apiKeyItem.status },
            "usageCount": { "N": apiKeyItem.usageCount.toString() },
            "usageLimit": { "N": apiKeyItem.usageLimit.toString() },
            ...(apiKeyItem.expireDate && { "expireDate": { "S": apiKeyItem.expireDate.toString() } })
        }
    };

    console.log("DynamoDB PutItem params:", JSON.stringify(params, null, 2));

    try {
        const command = new PutItemCommand(params);
        const result = await client.send(command);
        return result;
    } catch (error) {
        console.error("Error saving API key:", error);
        throw error;
    }
}


// Function to generate a secure random API key
function generateApiKey() {
    return crypto.randomBytes(32).toString('hex');  // Generates a 64-character hexadecimal string
}


async function handleReqApiKey(subscriber, inputArgs = {}) {
    const requestedUser = typeof inputArgs.user === "string" ? inputArgs.user.trim() : "";
    const requestedCustomer = typeof inputArgs.customer === "string" ? inputArgs.customer.trim() : "";
    const customerId = subscriber.sub || requestedUser;
    const customerEmail = subscriber.email;
    const customer = requestedCustomer || "guest";
    if (!customerId) {
        return { apiKey: null, message: "Missing customer ID." };
    }

    try {
        // Generate a new API key
        const apiKey = generateApiKey();
        console.log("APIKEY:"+apiKey+" CustomeID:"+customerId );

        // Define the new API key item
        const apiKeyItem = {
            apikey: apiKey,
            customerId: customerId,
            customerEmail:customerEmail,
            customer,
            status: "active",
            usageCount: 0,  // Initialize usage count
            usageLimit: 10000,  // Example usage limit
            expireDate: "2028-01-01",  // You can set this as per your business logic
        };

        // Save the new API key to DynamoDB
        await saveApiKey(apiKeyItem);

        return { apiKey, apiKeyId: scrambleApiKey(apiKey), message: "API key generated successfully." };

    } catch (error) {
        console.error("Error generating API key:", error);
        return { apiKey: null, apiKeyId: null, message: "Error generating API key." };
    }
}

function descrambleApiKey(scrambled) {
    const decoded = Buffer.from(scrambled, "base64").toString("utf8");
    if (!decoded.startsWith("ECB|")) {
        throw new Error("Invalid key format");
    }
    return decoded.slice(4); // remove 'ECB|' prefix
}

function normalizeApiKey(input) {
    if (!input) return null;
    try {
        return descrambleApiKey(input);
    } catch {
        return input;
    }
}

function scrambleApiKey(rawApiKey) {
    if (!rawApiKey) return null;
    return Buffer.from(`ECB|${rawApiKey}`, "utf8").toString("base64");
}

function extractApiKeyCandidate(inputArgs = {}) {
    return inputArgs.aws_api_key || inputArgs.apiKey || inputArgs.apiKeyId || null;
}

function parseMaskedApiKey(input) {
    if (typeof input !== "string") return null;
    const value = input.trim();
    const firstStar = value.indexOf("*");
    const lastStar = value.lastIndexOf("*");

    if (firstStar <= 0 || firstStar !== lastStar || firstStar >= value.length - 1) {
        return null;
    }

    const prefix = value.slice(0, firstStar);
    const suffix = value.slice(firstStar + 1);

    if (!prefix || !suffix) {
        return null;
    }

    return { prefix, suffix, masked: value };
}

async function resolveApiKeyFromMasked(maskedSpec) {
    let lastEvaluatedKey;
    const candidates = [];

    do {
        const params = {
            TableName: "ECBApiKeys",
            ProjectionExpression: "apikey",
            FilterExpression: "begins_with(apikey, :prefix)",
            ExpressionAttributeValues: {
                ":prefix": { S: maskedSpec.prefix },
            },
            ...(lastEvaluatedKey ? { ExclusiveStartKey: lastEvaluatedKey } : {}),
        };

        const command = new ScanCommand(params);
        const result = await client.send(command);
        const pageItems = (result.Items || [])
            .map((item) => item?.apikey?.S)
            .filter((key) => typeof key === "string" && key.endsWith(maskedSpec.suffix));

        candidates.push(...pageItems);
        lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    const uniqueCandidates = [...new Set(candidates)];
    if (uniqueCandidates.length === 1) {
        return { apiKey: uniqueCandidates[0] };
    }
    if (uniqueCandidates.length === 0) {
        return { error: "not_found" };
    }
    return { error: "ambiguous_match", count: uniqueCandidates.length };
}

// Function to query an API key from DynamoDB
async function handleQueryApiKey(args) {
    const apiKey = normalizeApiKey(extractApiKeyCandidate(args));
    console.log("apikey to be check:", apiKey);

    if (!apiKey) {
        return { customer: "guest", user: null, status: "missing_api_key" };
    }

    const params = {
        TableName: "ECBApiKeys",
        KeyConditionExpression: "apikey = :apikey",
        ExpressionAttributeValues: {
            ":apikey": { S: apiKey },
        },
        ProjectionExpression: "#usr, #st, #cus",
        ExpressionAttributeNames: {
            "#usr": "user",
            "#st": "status",
            "#cus": "customer",
        },
    };

    try {
        const command = new QueryCommand(params);
        const result = await client.send(command);

        if (!result.Items || result.Items.length === 0) {
            return { customer: "guest", user: null, status: "not_found" };
        }

        const item = result.Items[0];
        const user = item?.user?.S ?? null;
        const status = item?.status?.S ?? "unknown";
        const customer = item?.customer?.S ?? "guest";

        return { customer, user, status };
    } catch (error) {
        console.error("Error querying API key:", error);
        return { customer: "guest", user: null, status: "error" };
    }
}

async function findUsersByApiKey(apiKey) {
    const params = {
        TableName: "ECBApiKeys",
        KeyConditionExpression: "apikey = :apikey",
        ExpressionAttributeValues: {
            ":apikey": { S: apiKey },
        },
        ProjectionExpression: "#usr",
        ExpressionAttributeNames: {
            "#usr": "user",
        },
    };

    const command = new QueryCommand(params);
    const result = await client.send(command);
    return (result.Items || [])
        .map((item) => item?.user?.S)
        .filter((value) => typeof value === "string" && value.length > 0);
}

async function deleteApiKeyByValue(apiKey, user) {
    const params = {
        TableName: "ECBApiKeys",
        Key: {
            apikey: { S: apiKey },
            user: { S: user },
        },
        ConditionExpression: "attribute_exists(apikey) AND attribute_exists(#usr)",
        ExpressionAttributeNames: {
            "#usr": "user",
        },
    };

    const command = new DeleteItemCommand(params);
    await client.send(command);
}

async function handleRemoveApiKey(inputList = []) {
    if (!Array.isArray(inputList) || inputList.length === 0) {
        return {
            success: false,
            removed: [],
            failed: [{ id: null, reason: "empty_input" }],
            message: "No API key ids provided",
        };
    }

    const removed = [];
    const failed = [];

    for (const id of inputList) {
        let apiKey = normalizeApiKey(id);

        const maskedSpec = parseMaskedApiKey(apiKey);
        if (maskedSpec) {
            try {
                const resolved = await resolveApiKeyFromMasked(maskedSpec);
                if (resolved.error) {
                    failed.push({ id, reason: resolved.error, ...(resolved.count ? { count: resolved.count } : {}) });
                    continue;
                }
                apiKey = resolved.apiKey;
            } catch (error) {
                console.error("Error resolving masked API key:", id, error);
                failed.push({ id, reason: "resolve_error", detail: error?.message || "unknown" });
                continue;
            }
        }

        if (!apiKey) {
            failed.push({ id, reason: "invalid_key" });
            continue;
        }

        try {
            const users = await findUsersByApiKey(apiKey);
            if (users.length === 0) {
                failed.push({ id, reason: "not_found" });
                continue;
            }

            for (const user of users) {
                await deleteApiKeyByValue(apiKey, user);
            }

            removed.push({ id, apiKeyId: scrambleApiKey(apiKey), deletedUsers: users.length });
        } catch (error) {
            if (error?.name === "ConditionalCheckFailedException") {
                failed.push({ id, reason: "not_found" });
                continue;
            }
            console.error("Error deleting API key:", id, error);
            failed.push({ id, reason: "error", detail: error?.message || "unknown" });
        }
    }

    return {
        success: failed.length === 0,
        requested: inputList.length,
        removed,
        failed,
        message: failed.length === 0 ? "API keys removed" : "Some API keys failed to remove",
    };
}


// exports.handler = async (event) => {
export const handler = async (event, contex) => {
    console.log("Received event:", JSON.stringify(event, null, 2));
    let response;
    // const customerId = event.requestContext.authorizer.principalId; // Assuming customer ID is passed via custom authorizer for api-key based authorization
    
    switch (event.info.parentTypeName) {
        case "Mutation":
            switch (event.info.fieldName) {
                case "reqApiKey":
                    response = await handleReqApiKey(event.identity.claims ?? {}, event.arguments?.input ?? {});
                    break;
                case "removeApiKey":
                    response = await handleRemoveApiKey(event.arguments?.input ?? []);
                    break;
                default:
                    return UNRECOGNIZED_INPUT;
            }
            break;
        case "Query":
            console.log("DEBUG", "processing query....");
  
            switch (event.info.fieldName) {
                case "queryApiKeys":
                    // query DB to get the row. 
                    response = await handleQueryApiKey(event.arguments?.input ?? event.arguments ?? {});
                    
                    break;
                
            default:
                return UNRECOGNIZED_INPUT;
            }
        break;
    }

    return response;
};

