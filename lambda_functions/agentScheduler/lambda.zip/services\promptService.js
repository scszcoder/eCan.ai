const crypto = require("crypto");
const {
  DynamoDBClient,
  PutItemCommand,
  UpdateItemCommand,
  DeleteItemCommand,
  GetItemCommand,
  ScanCommand
} = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");

const REGION = process.env.AWS_REGION || "us-east-1";
const TABLE_NAME =
  process.env.PROMPTS_TABLE_NAME ||
  process.env.PromptsTableName ||
  process.env.PROMPTS_TABLE ||
  "prompts"; // Dynamo table name in this environment

const DEFAULT_VERSION = "0.1";

const dynamo = new DynamoDBClient({ region: REGION });
const MARSHALL_OPTIONS = { removeUndefinedValues: true };

function genId() {
  return `prompt_${crypto.randomBytes(8).toString("hex")}`;
}

function serializePrompt(payload) {
  if (payload === null || payload === undefined) {
    return "{}";
  }
  if (typeof payload === "string") {
    return payload;
  }
  try {
    return JSON.stringify(payload);
  } catch (err) {
    return "{}";
  }
}

function hydratePrompt(item) {
  if (!item) {
    return null;
  }
  const prompt = unmarshall(item);
  if (prompt.prompt && typeof prompt.prompt === "string") {
    try {
      prompt.prompt = JSON.parse(prompt.prompt);
    } catch (err) {
      // leave as the original string if parsing fails
    }
  } else if (!prompt.prompt) {
    prompt.prompt = {};
  }
  if (!prompt.version) {
    prompt.version = DEFAULT_VERSION;
  }
  return prompt;
}

async function addPrompt(data = {}) {
  if (!TABLE_NAME) {
    throw new Error("PROMPTS table name is not configured");
  }
  const owner = data.owner;
  if (!owner) {
    throw new Error("Owner is required to add a prompt");
  }
  const id = data.id || genId();
  const now = new Date().toISOString();
  const item = {
    id,
    owner,
    uid: owner, // sort key
    version: data.version || DEFAULT_VERSION,
    prompt: serializePrompt(data.prompt),
    created_at: now,
    updated_at: now
  };
  await dynamo.send(
    new PutItemCommand({
      TableName: TABLE_NAME,
      Item: marshall(item, MARSHALL_OPTIONS),
      ConditionExpression: "attribute_not_exists(#id) AND attribute_not_exists(#uid)",
      ExpressionAttributeNames: { "#id": "id", "#uid": "uid" }
    })
  );
  return { success: true, id };
}

async function updatePrompt(id, owner, fields = {}) {
  if (!TABLE_NAME) {
    throw new Error("PROMPTS table name is not configured");
  }
  if (!id) {
    throw new Error("Prompt id is required");
  }
  if (!owner) {
    throw new Error("Owner is required to update a prompt");
  }
  const now = new Date().toISOString();
  const updateParts = ["#updated_at = :updated_at"];
  const names = { "#owner": "owner", "#updated_at": "updated_at" };
  const values = { ":owner": owner, ":updated_at": now };

  if (Object.prototype.hasOwnProperty.call(fields, "version")) {
    updateParts.push("#version = :version");
    names["#version"] = "version";
    values[":version"] = fields.version || DEFAULT_VERSION;
  }

  if (Object.prototype.hasOwnProperty.call(fields, "prompt")) {
    updateParts.push("#prompt = :prompt");
    names["#prompt"] = "prompt";
    values[":prompt"] = serializePrompt(fields.prompt);
  }

  const updateExpression = `SET ${updateParts.join(", ")}`;

  await dynamo.send(
    new UpdateItemCommand({
      TableName: TABLE_NAME,
      Key: marshall({ id, uid: owner }, MARSHALL_OPTIONS),
      UpdateExpression: updateExpression,
      ConditionExpression: "#owner = :owner",
      ExpressionAttributeNames: names,
      ExpressionAttributeValues: marshall(values, MARSHALL_OPTIONS)
    })
  );

  return { success: true, id };
}

async function deletePrompt(id, owner) {
  if (!TABLE_NAME) {
    throw new Error("PROMPTS table name is not configured");
  }
  if (!id) {
    throw new Error("Prompt id is required");
  }
  if (!owner) {
    throw new Error("Owner is required to remove a prompt");
  }
  await dynamo.send(
    new DeleteItemCommand({
      TableName: TABLE_NAME,
      Key: marshall({ id, uid: owner }, MARSHALL_OPTIONS),
      ConditionExpression: "#owner = :owner",
      ExpressionAttributeNames: { "#owner": "owner" },
      ExpressionAttributeValues: marshall({ ":owner": owner }, MARSHALL_OPTIONS)
    })
  );
  return { success: true };
}

async function getPromptById(id, owner) {
  if (!id) {
    return null;
  }
  if (!owner) {
    throw new Error("Owner is required to fetch a prompt");
  }
  if (!TABLE_NAME) {
    throw new Error("PROMPTS table name is not configured");
  }
  const result = await dynamo.send(
    new GetItemCommand({
      TableName: TABLE_NAME,
      Key: marshall({ id, uid: owner }, MARSHALL_OPTIONS)
    })
  );
  const prompt = hydratePrompt(result.Item);
  if (!prompt) {
    return null;
  }
  if (prompt.owner !== owner) {
    return null;
  }
  return prompt;
}

function buildFilter({ owner, version, search }) {
  const expressionParts = [];
  const names = {};
  const values = {};

  if (owner) {
    names["#owner"] = "owner";
    values[":owner"] = owner;
    expressionParts.push("#owner = :owner");
  }

  if (version) {
    names["#version"] = "version";
    values[":version"] = version;
    expressionParts.push("#version = :version");
  }

  if (search) {
    names["#prompt"] = "prompt";
    values[":search"] = search;
    expressionParts.push("contains(#prompt, :search)");
  }

  return {
    FilterExpression: expressionParts.length ? expressionParts.join(" AND ") : undefined,
    ExpressionAttributeNames: Object.keys(names).length ? names : undefined,
    ExpressionAttributeValues: Object.keys(values).length ? marshall(values, MARSHALL_OPTIONS) : undefined
  };
}

async function scanPrompts(params) {
  if (!TABLE_NAME) {
    throw new Error("PROMPTS table name is not configured");
  }
  const {
    FilterExpression,
    ExpressionAttributeNames,
    ExpressionAttributeValues
  } = buildFilter(params);
  const items = [];
  let startKey;
  do {
    const scanParams = {
      TableName: TABLE_NAME,
      ExclusiveStartKey: startKey
    };
    if (FilterExpression) {
      scanParams.FilterExpression = FilterExpression;
      if (ExpressionAttributeNames) {
        scanParams.ExpressionAttributeNames = ExpressionAttributeNames;
      }
      if (ExpressionAttributeValues) {
        scanParams.ExpressionAttributeValues = ExpressionAttributeValues;
      }
    }
    const res = await dynamo.send(new ScanCommand(scanParams));
    if (res.Items) {
      items.push(...res.Items.map(hydratePrompt));
    }
    startKey = res.LastEvaluatedKey;
  } while (startKey);
  return items;
}

async function listPrompts(owner) {
  if (!owner) {
    throw new Error("Owner is required to list prompts");
  }
  return scanPrompts({ owner });
}

async function queryPrompts({ id, owner, version, search } = {}) {
  if (!owner) {
    throw new Error("Owner is required to query prompts");
  }
  if (id) {
    const prompt = await getPromptById(id, owner);
    if (!prompt) {
      return [];
    }
    if (version && prompt.version !== version) {
      return [];
    }
    if (search) {
      const haystack = typeof prompt.prompt === "string" ? prompt.prompt : JSON.stringify(prompt.prompt || {});
      if (!haystack.includes(search)) {
        return [];
      }
    }
    return [prompt];
  }
  return scanPrompts({ owner, version, search });
}

module.exports = {
  addPrompt,
  updatePrompt,
  deletePrompt,
  getPromptById,
  listPrompts,
  queryPrompts
};
